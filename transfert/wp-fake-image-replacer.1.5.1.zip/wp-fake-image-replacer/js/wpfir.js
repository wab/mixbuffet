(function($) {
	$(document).ready(function() {

		$('.color-field').wpColorPicker();

	});
})(jQuery);
